<?php
// Heading
    $_['heading_title']    = 'Active Links';

    $_['text_module']      = 'Modules';
    $_['text_success']     = 'Success: You have modified Active Links!';
    $_['text_edit']        = 'Edit';
    $_['text_add']        = 'Add Column';

    // Entry
    $_['entry_status']     = 'Status';

    // Error
    $_['error_permission'] = 'Warning: You do not have permission to modify Active Links module!';